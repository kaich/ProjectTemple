//
//  UIFactory.m
//  I4Web
//
//  Created by Mac on 14-5-13.
//  Copyright (c) 2014年 Mac. All rights reserved.
//

#import "UIFactory.h"

@implementation UIFactory



@end
