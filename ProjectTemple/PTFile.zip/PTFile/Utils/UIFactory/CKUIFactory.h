//
//  CKUIFactory.h
//  ProjectTemple
//
//  Created by Mac on 14-5-28.
//  Copyright (c) 2014年 Mac. All rights reserved.
//

#import "UIFactory+TextField.h"
#import "UIFactory+Button.h"
#import "UIFactory+Switch.h"
#import "UIFactory+TableView.h"
#import "UIFactory+Label.h"
#import "UIFactory+Line.h"
#import "UIFactory+ImageView.h"
#import "UIFactory+StatusNotificationView.h"
#import "UIFactory+InfiniteView.h"
#import "UIFactory+StatusbarNotification.h"