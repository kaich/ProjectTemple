@import UIKit;
@import QuartzCore;

@interface UIView (Snapshot)

- (UIImage *)snapshot;

@end
