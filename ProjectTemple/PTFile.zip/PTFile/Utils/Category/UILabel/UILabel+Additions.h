//
//  UILabel+Additions.h
//  
//
//  Created by lixiang on 13-11-5.
//  Copyright (c) 2013年 All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (Additions)

- (void)adjustFontWithMaxSize:(CGSize)maxSize;

@end
