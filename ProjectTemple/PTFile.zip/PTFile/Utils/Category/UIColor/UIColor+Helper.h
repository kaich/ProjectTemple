//
//  UIColor+Helper.h

//
//  Created by Reejo Samuel on 8/2/13.
//  Copyright (c) 2013 Reejo Samuel | m[at]reejosamuel.com All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (Helper)

+(UIColor *)colorWithHex:(int)hex;


@end
