//
//  CKAPPDetailViewController.h
//  ProjectTemple
//
//  Created by Mac on 14-5-29.
//  Copyright (c) 2014年 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CKAPPDetailViewController : BaseViewController

@end
