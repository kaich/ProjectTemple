//
//  UIViewController+Base.m
//  ProjectTemple
//
//  Created by mac on 14/11/7.
//  Copyright (c) 2014年 mac. All rights reserved.
//

#import "UIViewController+Base.h"

@implementation UIViewController (Base)

@end
