//
//  UITableView+Base.h
//  ProjectTemple
//
//  Created by 程凯 on 14/11/12.
//  Copyright (c) 2014年 程凯. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITableView (Base)

- (void)insertRowAtBottom:(NSInteger) count;

@end
