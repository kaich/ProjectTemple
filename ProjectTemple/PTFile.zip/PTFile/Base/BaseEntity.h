//
//  BaseEntity.h
//  ProjectTemple
//
//  Created by mac on 14/11/10.
//  Copyright (c) 2014年 mac. All rights reserved.
//

#import "MTLModel.h"

@interface BaseEntity : MTLModel

@end
